# Signup-Login

## Project setup
```
npm install
```

### Compiles and hot-reloads for development
```
npm run serve
```

### Compiles and minifies for production
```
npm run build
```

### Lints and fixes files
```
npm run lint
```

### Customize configuration
See [Configuration Reference](https://cli.vuejs.org/config/).

Feel free to reach me on 
Email      waqar.shamstanoli@gmail.com  OR  
Whatsapp   +923458112216
