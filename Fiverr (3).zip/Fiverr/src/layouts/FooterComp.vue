<template>
  <v-card class="py-16 py-md-8 background">
    <v-row class="">
      <v-col cols="12" lg="12" md="12" sm="12">
        <div class="text-center">
          <h1 class="text-center text-h3 font-weight-bold mt-16">
            WARNINGS AND
            <span class="amber darken-2 white--text px-2"> PRECAUTIONS </span>
          </h1>
          <img src="../assets/Rectangle 43.svg" alt="" />
        </div>
      </v-col>
      <v-col cols="12" lg="12" md="12" sm="12">
        <div class="text-center">
          <img src="../assets/Group 4611.svg" alt="" />
        </div>
      </v-col>
    </v-row>
    <v-row class="mt-16 justify-center">
      <v-col cols="12" lg="4" md="12" sm="12" class="pl-md-12">
        <div class="text-center text-md-left">
          <img src="../assets/Group 4619.svg" class="ml-md-16" alt="" />
        </div>
        <p class="white--text ml-md-16 mt-6 text-center text-md-left">
          Copyright © 2023 Zimed. All rights reserved
        </p></v-col
      >
      <v-col cols="12" lg="2" md="12" sm="12">
        <h6 class="white--text text-h6 text-center text-md-left">Company</h6>
        <p class="white--text text-body-1 mt-8 text-center text-md-left">
          For Patients
        </p>
        <p class="white--text text-body-1 mt-6 mb-0 text-center text-md-left">
          For Doctors
        </p>
      </v-col>
      <v-col cols="12" lg="3" md="12" sm="12">
        <h6 class="white--text text-h6 text-center text-md-left">Reach us</h6>
        <v-card
          color="transparent"
          width="68%"
          class="mx-auto mx-md-0 elevation-0"
        >
          <div class="d-flex mt-8">
            <img src="../assets/sms.svg" alt="" />
            <p class="white--text text-body-1 ml-3 mb-0">
              contact@@aequuspharma.ca
            </p>
          </div>
          <div class="d-flex mt-6">
            <img src="../assets/call.svg" alt="" />
            <p class="white--text text-body-1 ml-3 mb-0">1-833-542-2633</p>
          </div>
          <div class="d-flex mt-6">
            <img src="../assets/location.svg" alt="" />
            <p class="white--text text-body-1 ml-3 mb-0 pt-5 pt-md-0">
              2820 - 200 Granville St.Vancouver, BCV6C 1S4
            </p>
          </div>
        </v-card>
      </v-col>
      <v-col cols="12" lg="3" md="12" sm="12">
        <img src="../assets/blue grey png 300x300 1.svg" alt="" />
      </v-col>
      <v-col cols="12" lg="12" md="12" sm="12">
        <div class="text-center">
          <img src="../assets/Vector 1.svg" width="90%" alt="" />
        </div>
      </v-col>
    </v-row>
    <v-card width="100%" color="transparent" class="mx-auto elevation-0">
      <v-row class="justify-space-between">
        <v-col cols="12" lg="3" md="12" sm="12">
          <p class="white--text body-2 text-center">
            Copyrights All right reserved @Zimed
          </p>
        </v-col>
        <v-col cols="12" lg="2" md="12" sm="12" class="mr-8">
          <div class="text-center text-md-left">
            <span class="white--text body-2">Privacy Policy</span>
            <span class="white--text body-2 ml-8">Terms of service</span>
          </div>
        </v-col>
      </v-row>
    </v-card>
  </v-card>
</template>
  <script>
export default {
  data() {
    return {};
  },
  methods: {},
};
</script>
  <style lang="scss">
</style>
  