<template>
  <div>
    <v-container>
      <router-view></router-view>
    </v-container>
  </div>
</template>
  <script>
export default {
  data() {
    return {};
  },
};
</script>
  <style>
</style>